This folder will hold the website's images (logo, hero banner, service photos, etc.).

Per the module brief, images must be either:
- Your own original photos, or
- Properly licensed / public-domain / Creative Commons images, with the source cited
  in the References section of README.md.

Add sourced images here as you gather them during Content Research and Sourcing (section 3
of the Part 1 brief), and reference each image's HTML src path + source in README.md.
